import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# Load dataset
df = pd.read_csv('titanic.csv')  # Make sure the file is in the same directory

# Display basic information
print("🔹 Dataset Shape:", df.shape)
print("\n🔹 Columns:\n", df.columns)
print("\n🔹 Missing Values:\n", df.isnull().sum())

# -----------------------------
# 🧹 Data Cleaning
# -----------------------------

# Fill missing 'Age' with median
df['Age'].fillna(df['Age'].median(), inplace=True)

# Fill missing 'Embarked' with mode
df['Embarked'].fillna(df['Embarked'].mode()[0], inplace=True)

# Fill missing 'Fare' if needed
df['Fare'].fillna(df['Fare'].median(), inplace=True)

# Replace missing 'Cabin' with 'Unknown'
df['Cabin'].fillna('Unknown', inplace=True)

# Convert columns to categorical
df['Survived'] = df['Survived'].astype('category')
df['Pclass'] = df['Pclass'].astype('category')
df['Sex'] = df['Sex'].astype('category')
df['Embarked'] = df['Embarked'].astype('category')

print("\n🔹 Data Types After Cleaning:\n", df.dtypes)

# -----------------------------
# 📊 Exploratory Data Analysis
# -----------------------------

# Set seaborn style
sns.set(style="whitegrid")

# 1. Survival Count
sns.countplot(data=df, x='Survived')
plt.title("Survival Count")
plt.xlabel("Survived (0 = No, 1 = Yes)")
plt.ylabel("Count")
plt.show()

# 2. Gender Distribution
sns.countplot(data=df, x='Sex', palette='Set2')
plt.title("Gender Distribution")
plt.show()

# 3. Survival by Sex
sns.countplot(data=df, x='Sex', hue='Survived', palette='pastel')
plt.title("Survival by Gender")
plt.show()

# 4. Survival by Pclass
sns.countplot(data=df, x='Pclass', hue='Survived', palette='muted')
plt.title("Survival by Passenger Class")
plt.show()

# 5. Age distribution
sns.histplot(df['Age'], bins=30, kde=True, color='skyblue')
plt.title("Age Distribution")
plt.xlabel("Age")
plt.show()

# 6. Age vs Survival
sns.boxplot(data=df, x='Survived', y='Age', palette='coolwarm')
plt.title("Age vs Survival")
plt.xticks([0, 1], ['Not Survived', 'Survived'])
plt.show()

# 7. Embarked vs Survival
sns.countplot(data=df, x='Embarked', hue='Survived', palette='Set3')
plt.title("Survival by Embarkation Port")
plt.show()

# 8. SibSp vs Survival
sns.countplot(data=df, x='SibSp', hue='Survived', palette='Set1')
plt.title("Survival by Siblings/Spouses Aboard")
plt.show()

# 9. Parch vs Survival
sns.countplot(data=df, x='Parch', hue='Survived', palette='Set2')
plt.title("Survival by Parents/Children Aboard")
plt.show()

# 10. Correlation Heatmap
numeric_df = df[['Survived', 'Age', 'SibSp', 'Parch', 'Fare']]
corr = numeric_df.corr()
sns.heatmap(corr, annot=True, cmap='Blues')
plt.title("Correlation Heatmap")
plt.show()

# -----------------------------
# ✅ Summary Statistics
# -----------------------------
print("\n🔹 Survival Rate by Gender:\n", df.groupby('Sex')['Survived'].value_counts(normalize=True))
print("\n🔹 Survival Rate by Class:\n", df.groupby('Pclass')['Survived'].value_counts(normalize=True))
print("\n🔹 Mean Age by Survival:\n", df.groupby('Survived')['Age'].mean())

# Optional: Save cleaned dataset
df.to_csv("titanic_cleaned.csv", index=False)
